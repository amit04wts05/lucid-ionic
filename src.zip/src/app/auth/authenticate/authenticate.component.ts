import { Component } from '@angular/core';


@Component({

  templateUrl:'authenticate.component.html',
  styleUrls:['authenticate.component.scss']
})
export class AuthenticateComponent{

  constructor(){

  }

}
