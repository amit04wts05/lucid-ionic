import { Component } from '@angular/core';


@Component({

  templateUrl:'search_result.component.html',
  styleUrls:['search_result.component.scss']
})
export class SearchResultComponent{

  constructor(){

  }
}
